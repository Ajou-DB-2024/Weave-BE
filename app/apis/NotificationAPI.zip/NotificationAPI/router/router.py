from fastapi import APIRouter
from app.apis.NotificationAPI.service.notification_service import NotificationService
from app.common.response.formatter import success_response, error_response

router = APIRouter()

@router.get("/noti/:noti_id")
async def get_notification(noti_id: int):
    """
    특정 알림 ID를 기반으로 단건 알림 데이터를 조회합니다.
    """
    try:
        # 서비스 레이어에서 알림 데이터를 가져옵니다.
        notification = NotificationService.get_notification(noti_id)
        if not notification:
            return error_response(
                error="NOTIFICATION_NOT_FOUND",
                message="Notification not found for the given id."
            )
        return success_response(data=notification)
    except ValueError as ve:
        # 값 검증 관련 예외 처리
        return error_response(error="VALIDATION_ERROR", message=str(ve))
    except Exception as e:
        # 일반 예외 처리
        return error_response(error="INTERNAL_SERVER_ERROR", message=str(e))


@router.get("/noti/list/:member_id")
async def get_notifications(member_id: int):
    """
    특정 회원 ID를 기반으로 알림 목록을 조회합니다.
    """
    try:
        # 서비스 레이어에서 알림 목록 데이터를 가져옵니다.
        notifications = NotificationService.get_notifications(member_id)
        if not notifications:
            return error_response(
                error="NOTIFICATIONS_NOT_FOUND",
                message="No notifications found for the given member_id."
            )
        return success_response(data=notifications)
    except ValueError as ve:
        # 값 검증 관련 예외 처리
        return error_response(error="VALIDATION_ERROR", message=str(ve))
    except Exception as e:
        # 일반 예외 처리
        return error_response(error="INTERNAL_SERVER_ERROR", message=str(e))
