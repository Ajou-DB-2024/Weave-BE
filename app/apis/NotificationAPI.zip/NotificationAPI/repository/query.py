GET_NOTIFICATION_BY_ID = """
SELECT id, notification_type, title, content, created_at
FROM notification
WHERE id = %s;
"""

GET_NOTIFICATIONS_BY_MEMBER_ID = """
SELECT n.id, n.notification_type, n.title, n.content, n.created_at
FROM notification n
JOIN notification_map nm ON n.id = nm.notification_id
WHERE nm.member_id = %s;
"""

GET_RESULT_ANNOUNCEMENT_COUNT = """
SELECT COUNT(*)
FROM notification n
JOIN notification_map nm ON n.id = nm.notification_id
WHERE nm.member_id = %s AND n.notification_type = '지원현황';
"""

GET_SERVICE_ANNOUNCEMENT_COUNT = """
SELECT COUNT(*)
FROM notification n
JOIN notification_map nm ON n.id = nm.notification_id
WHERE nm.member_id = %s AND n.notification_type = '공지사항';
"""
