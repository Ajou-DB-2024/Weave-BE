from pydantic import BaseModel
from datetime import datetime
from typing import List


# 알림 단건 모델
class Notification(BaseModel):
    id: int
    notification_type: str
    title: str
    content: str
    created_at: datetime

# 알림 목록 조회 응답 모델
class NotificationListResponse(BaseModel):
    notifications: List[Notification]
    result_announcement_count: int
    service_announcement_count: int
