from app.apis.NotificationAPI.repository.repository import NotificationRepository
from datetime import datetime


class NotificationService:
    @staticmethod
    def get_notification(noti_id: int) -> dict:
        """
        단건 알림 데이터를 반환합니다.
        """
        result = NotificationRepository.get_notification_by_id(noti_id)
        if not result:
            raise ValueError("Notification not found.")

        # 결과를 dict 형태로 가공
        notification = result[0]
        return {
            "id": notification[0],
            "notification_type": notification[1],
            "title": notification[2],
            "content": notification[3],
            "created_at": notification[4]
        }

    @staticmethod
    def get_notifications(member_id: int) -> list:
        """
        특정 회원의 모든 알림 데이터를 반환합니다.
        """
        # Raw notification 데이터를 가져옴
        raw_notifications = NotificationRepository.get_notifications_by_member_id(member_id)
        notifications = [
            {
                "id": row[0],
                "notification_type": row[1],
                "title": row[2],
                "content": row[3],
                "created_at": row[4]
            }
            for row in raw_notifications
        ]

        # 결과 발표 알림 개수와 서비스 공지사항 알림 개수 가져옴
        result_announcement_count = NotificationRepository.get_result_announcement_count(member_id)
        service_announcement_count = NotificationRepository.get_service_announcement_count(member_id)

        return {
            "notifications": notifications,
            "result_announcement_count": result_announcement_count[0][0] if result_announcement_count else 0,
            "service_announcement_count": service_announcement_count[0][0] if service_announcement_count else 0,
        }
